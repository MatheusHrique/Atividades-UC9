package java.uc9;
import java.util.Scanner;

public class JavaUC9 {

    public static void main(String[] args) {
        
       Scanner lerTeclado = new Scanner(System.in);
       Banco cliente = new Banco(); // tenho que descobrir como instanciar novamente
        
    }
    
    public interface InterfaceBanco {
        public abstract void depositar(float valor);
        public abstract void sacar(float valor);
        public abstract void exibir();
    }
    
    public class Banco implements InterfaceBanco{
        
        private String titular;
        private float saldo;
        private short numeroConta;
        
        public Banco(String titular, float saldo, short numeroConta){
            this.titular=titular;
            this.saldo=saldo;
            this.numeroConta=numeroConta;
        }

        @Override
        public void depositar(float valor) {
            this.saldo+=valor;
            System.out.println("\nValor depositado!\n");
        }

        @Override
        public void sacar(float valor) {
            this.saldo+=-valor;
            if(valor>this.saldo){
                System.out.println("\nAmigo, tua conta vai ficar negativada, mas tudo bem.\nValor sacado!\n");
            } else {
                System.out.println("\nValor sacado!\n");
            }
        }

        @Override
        public void exibir() {
            System.out.println("\nNumero da conta: #" + getNumeroConta() + ".\nTitular: " + getTitular() + ".\nSaldo: R$ " + getSaldo() + ".\n");
        }
        
        public float getSaldo(){
            return this.saldo;
        }
        
        public void setSaldo(float valor){
            this.saldo=valor;
        }
        
        public String getTitular(){
            return this.titular;
        }
        
        public void setTitular(String valor){
            this.titular=valor;
        }
        
        public short getNumeroConta(){
            return this.numeroConta;
        }
        
        public void setNumeroConta(short valor){
            this.numeroConta=valor;
        }
    }
    
}
