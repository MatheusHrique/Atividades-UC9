package java.uc9;
import java.util.Scanner;

public class Banco {

    private String titular;
    private double saldo;
    private int numeroConta;

    public Banco(String titular, double saldo, int numeroConta){
        this.titular=titular;
        this.saldo=saldo;
        this.numeroConta=numeroConta;
    }

    public void depositar(float valor) {
        this.saldo+=valor;
        System.out.println("\nValor depositado!\n");
    }

    public void sacar(float valor) {
        this.saldo+=-valor;
        if(valor>this.saldo){
            System.out.println("\nAmigo, tua conta vai ficar negativada, mas tudo bem.\nValor sacado!\n");
        } else {
            System.out.println("\nValor sacado!\n");
        }
    }

    public void exibir() {
        System.out.println("\nNumero da conta: #" + getNumeroConta() + ".\nTitular: " + getTitular() + ".\nSaldo: R$ " + getSaldo() + ".\n");
    }

    public double getSaldo(){
        return this.saldo;
    }

    public void setSaldo(double valor){
        this.saldo=valor;
    }

    public String getTitular(){
        return this.titular;
    }

    public void setTitular(String valor){
        this.titular=valor;
    }

    public int getNumeroConta(){
        return this.numeroConta;
    }

    public void setNumeroConta(int valor){
        this.numeroConta=valor;
    }
    
    public static void main(String[] args) {
        Banco b = new Banco("eu", 100.0, 1);
        Scanner lerTeclado = new Scanner(System.in);
        System.out.println("Abc");
    }
}



